export const state = () => ({
  anakAktif: 0,
  nominal: 1000000,
  kode: 110,
  bukti: false,
  tahap: 'idle',
  notifikasi: [
    { judul: 'Transaksi kantin berhasil', isi: 'Aditya membayar Rp 19.000 di Kantin Utama. Sisa saldo Rp 245.000.', waktu: '09.12', baru: true },
    { judul: 'Saldo Kayla menipis', isi: 'Sisa Rp 11.500, di bawah ambang Rp 20.000. Isi saldo sekarang?', waktu: '08.05', baru: true },
    { judul: 'Tagihan SPP September terbit', isi: 'Rp 450.000 untuk Aditya Pratama, jatuh tempo 10 September.', waktu: 'Kemarin', baru: false },
    { judul: 'Top-up disetujui', isi: 'Rp 264.000 masuk ke dompet Aditya. Kode unik 083.', waktu: 'Kemarin', baru: false },
    { judul: 'Transaksi ditolak — saldo kurang', isi: 'Percobaan bayar Rp 15.000 di Kantin Utama ditolak. Saldo Kayla saat itu Rp 8.000.', waktu: '31 Agu', baru: false }
  ]
})

export const getters = {
  transfer: (s) => s.nominal + s.kode,
  kodeStr: (s) => String(s.kode).padStart(3, '0')
}

export const mutations = {
  setAnak(s, i) { s.anakAktif = Number(i) },
  setNominal(s, n) { s.nominal = Number(n) || 0 },
  acakKode(s) { s.kode = 100 + Math.floor(Math.random() * 900) },
  setBukti(s, v) { s.bukti = v },
  setTahap(s, v) { s.tahap = v },
  reset(s) { s.bukti = false; s.tahap = 'idle' }
}

export const actions = {
  mulaiTopup({ commit }, nominal) {
    if (nominal) commit('setNominal', nominal)
    commit('acakKode')
    commit('reset')
  },
  kirimBukti({ commit }) {
    commit('setTahap', 'menunggu')
  },
  setujuiTopup({ state, getters, commit }) {
    commit('setTahap', 'disetujui')
    commit('kreditSaldo', { anak: state.anakAktif, nominal: getters.transfer }, { root: true })
  }
}
