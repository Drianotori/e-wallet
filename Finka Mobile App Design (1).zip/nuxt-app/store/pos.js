export const state = () => ({
  outlet: 0,
  mode: 'belanja',
  cart: {},
  tunai: 0,
  kasSesi: 420000,
  scanId: null,
  pin: '',
  pinGagal: 0,
  keypad: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
})

export const getters = {
  totalBelanja: (s, g, root) =>
    Object.keys(s.cart).reduce((a, id) => {
      const p = root.produk.find((x) => x.id === id)
      return a + (p ? p.harga * s.cart[id] : 0)
    }, 0),
  total: (s, g) => (s.mode === 'tunai' ? s.tunai : g.totalBelanja),
  jumlahItem: (s) => Object.keys(s.cart).reduce((a, k) => a + s.cart[k], 0),
  items: (s, g, root) =>
    s.mode === 'tunai'
      ? [{ label: 'Ambil tunai di kasir', harga: s.tunai }]
      : Object.keys(s.cart).map((id) => {
          const p = root.produk.find((x) => x.id === id)
          return { label: p.nama + ' ×' + s.cart[id], harga: p.harga * s.cart[id] }
        }),
  siswaScan: (s, g, root) => (s.scanId === null ? null : root.siswa[s.scanId]),
  cukup: (s, g) => (g.siswaScan ? g.siswaScan.saldo >= g.total : false)
}

export const mutations = {
  setOutlet(s, i) { s.outlet = Number(i) },
  setMode(s, m) { s.mode = m },
  tambah(s, id) { s.cart = Object.assign({}, s.cart, { [id]: (s.cart[id] || 0) + 1 }) },
  kosongkan(s) { s.cart = {} },
  setTunai(s, n) { s.tunai = Math.max(0, Math.min(Number(n) || 0, 9999999)) },
  setScan(s, i) { s.scanId = i === null ? null : Number(i) },
  setPin(s, v) { s.pin = v },
  gagalPin(s) { s.pinGagal += 1 },
  acakKeypad(s) {
    const a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      const t = a[i]; a[i] = a[j]; a[j] = t
    }
    s.keypad = a
  },
  kurangiKas(s, n) { s.kasSesi = Math.max(0, s.kasSesi - n) },
  reset(s) {
    s.cart = {}
    s.mode = 'belanja'
    s.tunai = 0
    s.scanId = null
    s.pin = ''
    s.pinGagal = 0
  }
}

export const actions = {
  selesaikan({ state, getters, commit }) {
    if (state.scanId === null) return
    commit('debitSaldo', { anak: state.scanId, nominal: getters.total }, { root: true })
    if (state.mode === 'tunai') commit('kurangiKas', getters.total)
  }
}
