export const state = () => ({
  peran: 'admin',
  pilihId: 'TU-2609-0413',
  hasil: {},
  alasan: '',
  outlet: 0,
  antrean: [
    { id: 'TU-2609-0413', siswa: 'Aditya Pratama', kelas: '7B', ortu: 'Sari Wulandari', dasar: 1000000, kode: 110, waktu: '2 Sep, 09.39', expired: '3 Sep, 09.36', cocok: true },
    { id: 'TU-2609-0412', siswa: 'Nabila Azzahra', kelas: '9A', ortu: 'Dewi Anggraini', dasar: 300000, kode: 472, waktu: '2 Sep, 08.51', expired: '3 Sep, 08.48', cocok: true },
    { id: 'TU-2609-0411', siswa: 'Rafi Ramadhan', kelas: '8C', ortu: 'Budi Santoso', dasar: 150000, kode: 205, waktu: '2 Sep, 08.14', expired: '3 Sep, 08.10', cocok: false },
    { id: 'TU-2609-0409', siswa: 'Kayla Pratama', kelas: '4A', ortu: 'Sari Wulandari', dasar: 200000, kode: 38, waktu: '2 Sep, 07.32', expired: '3 Sep, 07.30', cocok: true },
    { id: 'TU-2609-0407', siswa: 'Farel Mahendra', kelas: '6B', ortu: 'Agus Priyanto', dasar: 500000, kode: 661, waktu: '1 Sep, 19.05', expired: '2 Sep, 19.02', cocok: true }
  ],
  kelas: [
    { kelas: '7A', n: 32, siswa: 'Zahra Alifia', nis: '24070118', ortu: 'Maya Kartika', lunas: 91, tunggakan: 1350000 },
    { kelas: '7B', n: 31, siswa: 'Aditya Pratama', nis: '24071023', ortu: 'Sari Wulandari', lunas: 84, tunggakan: 2250000 },
    { kelas: '8A', n: 30, siswa: 'Rafi Ramadhan', nis: '24080411', ortu: 'Budi Santoso', lunas: 63, tunggakan: 4950000 },
    { kelas: '8C', n: 29, siswa: 'Farel Mahendra', nis: '24081907', ortu: 'Agus Priyanto', lunas: 48, tunggakan: 6750000 },
    { kelas: '9A', n: 28, siswa: 'Nabila Azzahra', nis: '24090233', ortu: 'Dewi Anggraini', lunas: 96, tunggakan: 450000 },
    { kelas: '9C', n: 30, siswa: 'Bagas Setiawan', nis: '24093140', ortu: 'Rina Kusuma', lunas: 41, tunggakan: 7650000 }
  ],
  totalSiswaSekolah: 1284,
  jenisTagihan: [
    { label: 'SPP bulanan', ket: 'Terbit otomatis tiap bulan', default: 450000, periode: 'Periode September 2026' },
    { label: 'Uang kegiatan', ket: 'Sekali per semester', default: 150000, periode: 'Semester 1 2026/2027' },
    { label: 'Seragam & buku', ket: 'Sesuai paket kelas', default: 385000, periode: 'Tahun ajaran 2026/2027' },
    { label: 'Tagihan lain', ket: 'Nominal bebas', default: 100000, periode: '2 September 2026' }
  ],
  tempoOpsi: [
    { label: '7 hari', ket: '9 Sep 2026', tanggal: '9 September 2026' },
    { label: '10 September', ket: 'standar SPP', tanggal: '10 September 2026' },
    { label: 'Akhir bulan', ket: '30 Sep 2026', tanggal: '30 September 2026' }
  ],
  draft: {
    jenis: 0,
    target: 0,
    kelasPilih: ['8A'],
    nominal: 450000,
    tempo: 1,
    kirimNotif: true,
    dendaOn: true,
    cicilan: false,
    terbit: false
  }
})

export const getters = {
  admin: (s) => s.peran === 'admin',
  status: (s) => (id) => s.hasil[id] || 'Menunggu Verifikasi',
  menunggu: (s, g) => s.antrean.filter((a) => g.status(a.id) === 'Menunggu Verifikasi'),
  pilih: (s) => s.antrean.find((a) => a.id === s.pilihId) || s.antrean[0],
  kelasTerpilih: (s) => s.kelas.filter((k) => s.draft.kelasPilih.indexOf(k.kelas) >= 0),
  jumlahPenerima: (s, g) => {
    if (s.draft.target === 2) return s.totalSiswaSekolah
    if (s.draft.target === 1) {
      const angkatan = g.kelasTerpilih.map((k) => k.kelas[0])
      return s.kelas.filter((k) => angkatan.indexOf(k.kelas[0]) >= 0).reduce((a, k) => a + k.n, 0)
    }
    return g.kelasTerpilih.reduce((a, k) => a + k.n, 0)
  },
  contohPenerima: (s, g) => (s.draft.target === 2 ? s.kelas[0] : g.kelasTerpilih[0] || s.kelas[0]),
  totalTerbit: (s, g) => s.draft.nominal * g.jumlahPenerima
}

export const mutations = {
  setPeran(s, v) { s.peran = v; s.alasan = '' },
  setPilih(s, id) { s.pilihId = id; s.alasan = '' },
  setAlasan(s, v) { s.alasan = v },
  setHasil(s, { id, status }) { s.hasil = Object.assign({}, s.hasil, { [id]: status }) },
  setOutlet(s, i) { s.outlet = Number(i) },
  patchDraft(s, patch) { s.draft = Object.assign({}, s.draft, patch, { terbit: patch.terbit === true }) },
  terbitkan(s) { s.draft = Object.assign({}, s.draft, { terbit: true }) },
  toggleKelas(s, kelas) {
    const cur = s.draft.kelasPilih.slice()
    const ix = cur.indexOf(kelas)
    if (ix >= 0) cur.splice(ix, 1)
    else cur.push(kelas)
    s.draft = Object.assign({}, s.draft, { kelasPilih: cur, terbit: false })
  }
}
