import Vue from 'vue'

export const num = (n) => Math.round(Number(n) || 0).toLocaleString('id-ID')
export const rp = (n) => 'Rp ' + num(n)
export const parseRp = (s) => parseInt(String(s).replace(/\D/g, ''), 10) || 0

Vue.filter('rp', rp)
Vue.filter('num', num)

Vue.mixin({
  methods: { $rp: rp, $num: num, $parseRp: parseRp }
})

export default (ctx, inject) => {
  inject('format', { rp, num, parseRp })
}
