<template>
  <div class="wrap">
    <ScreenHeader title="Riwayat Belanja Anak" to="/ortu" />
    <div class="filter">
      <button
        v-for="(f, i) in filterOpsi"
        :key="i"
        class="chip chip--pill"
        :class="filter === i ? 'chip--on' : ''"
        @click="filter = i"
      >{{ f }}</button>
    </div>
    <div class="body">
      <div v-for="h in hari" :key="h.tanggal" class="hari">
        <div class="hari__head">
          <span>{{ h.tanggal }}</span>
          <span class="num">{{ h.total }}</span>
        </div>
        <div class="card">
          <TrxRow v-for="t in h.items" :key="t.id" :trx="t" :to="'/siswa/struk/' + t.id" show-sisa />
        </div>
      </div>
    </div>
    <OrtuTabBar />
  </div>
</template>

<script>
export default {
  layout: 'phone',
  data() {
    return { filter: 0 }
  },
  computed: {
    siswa() { return this.$store.state.siswa },
    filterOpsi() { return ['Semua'].concat(this.siswa.map((s) => s.nama.split(' ')[0])) },
    daftar() {
      const all = this.$store.state.trx
      return this.filter === 0 ? all : all.filter((t) => t.anak === this.filter - 1)
    },
    hari() {
      const out = []
      this.daftar.forEach((t) => {
        let g = out.find((x) => x.tanggal === t.hari)
        if (!g) { g = { tanggal: t.hari, keluar: 0, items: [] }; out.push(g) }
        g.items.push(t)
        if (t.nominal < 0) g.keluar += -t.nominal
      })
      return out.map((g) => ({
        tanggal: g.tanggal,
        total: g.keluar ? '− ' + this.$num(g.keluar) : '—',
        items: g.items
      }))
    }
  },
  mounted() {
    const q = this.$route.query.anak
    if (q !== undefined) this.filter = Number(q) + 1
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: var(--bg); min-height: 0; }
.filter { display: flex; gap: 8px; padding: 14px 18px; background: #fff; border-bottom: 1px solid var(--line); flex: none; }
.body { flex: 1; overflow-y: auto; padding: 16px 18px; display: flex; flex-direction: column; gap: 18px; }
.hari { display: flex; flex-direction: column; gap: 9px; }
.hari__head { display: flex; align-items: center; justify-content: space-between; font: 600 11.5px var(--font-body); color: var(--muted); letter-spacing: .04em; }
</style>
