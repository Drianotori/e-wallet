<template>
  <div class="wrap">
    <ScreenHeader title="Status Top-up" to="/ortu" />
    <div class="body">
      <div class="card status" :class="selesai ? 'status--ok' : ''">
        <div class="status__ik">
          <svg v-if="selesai" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
          <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--sand-ink)" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
        </div>
        <div class="status__judul display">{{ selesai ? 'Saldo bertambah' : 'Menunggu verifikasi admin' }}</div>
        <p class="status__pesan">{{ pesan }}</p>
        <div class="status__nominal display num" :class="selesai ? 'is-ok' : ''">{{ transfer | rp }}</div>
      </div>

      <div class="card lini">
        <div class="lini__judul display">Lini masa</div>
        <div v-for="(t, i) in timeline" :key="i" class="lini__item">
          <div class="lini__rail">
            <span class="dot" :style="'background:' + t.dot"></span>
            <span class="line" :style="'background:' + t.line"></span>
          </div>
          <div>
            <div class="lini__t" :style="'color:' + t.fg">{{ t.judul }}</div>
            <div class="lini__w">{{ t.waktu }}</div>
          </div>
        </div>
      </div>

      <div class="card rincian">
        <div><span>Untuk</span><b>{{ aktif.nama }}</b></div>
        <div><span>Kode unik</span><b class="num">{{ kodeStr }}</b></div>
        <div><span>ID permintaan</span><b class="num">TU-2609-0413</b></div>
      </div>

      <div class="spacer"></div>
      <button v-if="!selesai" class="simulasi" @click="setujui">Simulasi: admin menyetujui top-up</button>
      <nuxt-link v-else to="/ortu" class="btn btn--primary">Kembali ke beranda</nuxt-link>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    selesai() { return this.$store.state.topup.tahap === 'disetujui' },
    transfer() { return this.$store.getters['topup/transfer'] },
    kodeStr() { return this.$store.getters['topup/kodeStr'] },
    aktif() { return this.$store.state.siswa[this.$store.state.topup.anakAktif] },
    pesan() {
      return this.selesai
        ? 'Top-up disetujui admin yayasan. Saldo ' + this.aktif.nama + ' sudah bisa dipakai di kantin dan koperasi.'
        : 'Admin akan mencocokkan bukti Anda dengan mutasi bank. Biasanya selesai dalam 1 jam kerja.'
    },
    timeline() {
      const hijau = 'var(--green)'
      return [
        { judul: 'Permintaan dibuat', waktu: '2 Sep, 09.36 WIB', dot: hijau, line: hijau, fg: 'var(--ink)' },
        { judul: 'Bukti transfer diunggah', waktu: '2 Sep, 09.39 WIB', dot: hijau, line: this.selesai ? hijau : 'var(--line)', fg: 'var(--ink)' },
        {
          judul: this.selesai ? 'Disetujui admin' : 'Menunggu verifikasi',
          waktu: this.selesai ? '2 Sep, 09.52 WIB' : 'Estimasi < 1 jam',
          dot: this.selesai ? hijau : 'var(--sand)',
          line: 'transparent',
          fg: this.selesai ? 'var(--ink)' : 'var(--muted)'
        }
      ]
    }
  },
  methods: {
    setujui() { this.$store.dispatch('topup/setujuiTopup') }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: var(--bg); min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 18px; display: flex; flex-direction: column; gap: 16px; }

.status { padding: 22px; display: flex; flex-direction: column; align-items: center; gap: 14px; }
.status--ok { border-color: var(--green); }
.status__ik {
  width: 56px; height: 56px; border-radius: var(--r-pill);
  background: rgba(192,169,127,.22);
  display: flex; align-items: center; justify-content: center;
}
.status--ok .status__ik { background: rgba(26,128,64,.12); }
.status__judul { font: 700 17px var(--font-display); text-align: center; }
.status__pesan { margin: 0; font: 400 12.5px/1.5 var(--font-body); color: var(--muted); text-align: center; max-width: 270px; text-wrap: pretty; }
.status__nominal { font: 800 26px var(--font-display); letter-spacing: -.02em; }
.status__nominal.is-ok { color: var(--green); }

.lini { padding: 16px; display: flex; flex-direction: column; gap: 14px; }
.lini__judul { font: 700 13px var(--font-display); }
.lini__item { display: flex; gap: 12px; align-items: flex-start; }
.lini__rail { width: 18px; display: flex; flex-direction: column; align-items: center; flex: none; }
.dot { width: 10px; height: 10px; border-radius: var(--r-pill); margin-top: 3px; }
.line { width: 2px; height: 22px; }
.lini__t { font: 600 13px var(--font-body); }
.lini__w { font: 400 11.5px var(--font-body); color: var(--muted); margin-top: 1px; }

.rincian { padding: 16px; display: flex; flex-direction: column; gap: 9px; }
.rincian div { display: flex; justify-content: space-between; }
.rincian span { font: 400 12.5px var(--font-body); color: var(--muted); }
.rincian b { font: 600 12.5px var(--font-body); }

.spacer { flex: 1; }
.simulasi {
  border: 1px dashed var(--sand); background: rgba(192,169,127,.12);
  border-radius: var(--r-sm); padding: 13px; width: 100%;
  font: 600 12px var(--font-body); color: var(--ink); cursor: pointer;
}
</style>
