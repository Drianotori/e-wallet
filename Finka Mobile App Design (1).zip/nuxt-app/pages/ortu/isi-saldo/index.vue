<template>
  <div class="wrap">
    <ScreenHeader title="Isi Saldo" to="/ortu" />
    <div class="body">
      <div class="anak">
        <div class="av">{{ aktif.inisial }}</div>
        <div class="anak__id">
          <div class="anak__nama">{{ aktif.nama }}</div>
          <div class="anak__saldo">Saldo {{ aktif.saldo | rp }}</div>
        </div>
        <button class="link" @click="ganti">Ganti</button>
      </div>

      <div>
        <div class="label">Nominal isi saldo</div>
        <div class="input">
          <span class="input__rp display">Rp</span>
          <input v-model="tampil" inputmode="numeric" class="input__field display num" />
        </div>
        <div class="chips">
          <button
            v-for="n in cepat"
            :key="n"
            class="chip num"
            :class="n === nominal ? 'chip--on' : ''"
            @click="nominal = n"
          >{{ n | num }}</button>
        </div>
      </div>

      <div class="info">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="1.8"><circle cx="12" cy="12" r="9" /><path d="M12 16v-5M12 8h.01" /></svg>
        <p>Saldo digunakan untuk jajan di kantin dan belanja koperasi. Untuk membayar SPP, gunakan menu Tagihan.</p>
      </div>

      <div class="spacer"></div>
      <button class="btn btn--primary" @click="lanjut">Lanjutkan</button>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  data() {
    return { cepat: [50000, 100000, 250000, 1000000] }
  },
  computed: {
    aktif() { return this.$store.state.siswa[this.$store.state.topup.anakAktif] },
    nominal: {
      get() { return this.$store.state.topup.nominal },
      set(v) { this.$store.commit('topup/setNominal', v) }
    },
    tampil: {
      get() { return this.$num(this.nominal) },
      set(v) { this.nominal = this.$parseRp(v) }
    }
  },
  mounted() {
    if (this.$route.query.nominal) this.nominal = this.$parseRp(this.$route.query.nominal)
  },
  methods: {
    ganti() {
      this.$store.commit('topup/setAnak', this.$store.state.topup.anakAktif === 0 ? 1 : 0)
    },
    lanjut() {
      this.$store.dispatch('topup/mulaiTopup', this.nominal)
      this.$router.push('/ortu/isi-saldo/instruksi')
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: #fff; min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 20px; }

.anak { display: flex; align-items: center; gap: 12px; background: var(--bg); border-radius: var(--r-md); padding: 12px 14px; }
.av {
  width: 36px; height: 36px; border-radius: var(--r-pill); flex: none;
  background: var(--blue-soft); color: var(--blue);
  display: flex; align-items: center; justify-content: center;
  font: 700 13px var(--font-display);
}
.anak__id { flex: 1; }
.anak__nama { font: 600 14px var(--font-body); }
.anak__saldo { font: 400 12px var(--font-body); color: var(--muted); }
.link { border: none; background: none; font: 600 12px var(--font-body); color: var(--blue); cursor: pointer; padding: 0; }

.label { font: 500 12px var(--font-body); color: var(--muted); margin-bottom: 8px; }
.input { display: flex; align-items: center; gap: 8px; border: 1.5px solid var(--blue); border-radius: var(--r-sm); padding: 14px 16px; }
.input__rp { font: 700 19px var(--font-display); }
.input__field { flex: 1; border: none; outline: none; font: 700 24px var(--font-display); color: var(--ink); letter-spacing: -.02em; width: 100%; }
.chips { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }

.info { background: var(--blue-soft); border-radius: var(--r-md); padding: 14px; display: flex; gap: 10px; }
.info p { margin: 0; font: 400 12.5px/1.5 var(--font-body); text-wrap: pretty; }
.info svg { flex: none; margin-top: 1px; }
.spacer { flex: 1; }
</style>
