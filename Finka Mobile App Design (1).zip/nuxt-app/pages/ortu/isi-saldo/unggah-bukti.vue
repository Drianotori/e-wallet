<template>
  <div class="wrap">
    <ScreenHeader title="Unggah Bukti Transfer" to="/ortu/isi-saldo/instruksi" />
    <div class="body">
      <div class="ringkas">
        <span>Nominal transfer</span>
        <span class="display num">{{ transfer | rp }}</span>
      </div>

      <button class="drop" :class="bukti ? 'drop--ok' : ''" @click="pilih">
        <template v-if="bukti">
          <div class="pratinjau">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--sand)" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
            <span>pratinjau bukti transfer<br />(placeholder)</span>
          </div>
          <div class="ok">bukti-transfer.jpg · 1,2 MB</div>
          <div class="ganti">Ganti foto</div>
        </template>
        <template v-else>
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="1.7"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" /><path d="M17 8l-5-5-5 5M12 3v13" /></svg>
          <div class="drop__judul display">Ambil foto atau pilih dari galeri</div>
          <div class="drop__ket">JPG atau PNG, maks 5 MB</div>
        </template>
      </button>

      <div class="spacer"></div>
      <button class="btn" :class="bukti ? 'btn--primary' : 'btn--off'" :disabled="!bukti" @click="kirim">
        Kirim untuk verifikasi
      </button>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    bukti() { return this.$store.state.topup.bukti },
    transfer() { return this.$store.getters['topup/transfer'] }
  },
  methods: {
    pilih() { this.$store.commit('topup/setBukti', true) },
    kirim() {
      if (!this.bukti) return
      this.$store.dispatch('topup/kirimBukti')
      this.$router.push('/ortu/isi-saldo/status')
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: #fff; min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 18px; }
.ringkas {
  background: var(--bg); border-radius: var(--r-md); padding: 14px 16px;
  display: flex; align-items: center; justify-content: space-between;
  font: 400 12.5px var(--font-body); color: var(--muted);
}
.ringkas span:last-child { font: 700 15px var(--font-display); color: var(--ink); }

.drop {
  border: 1.5px dashed var(--blue); background: var(--blue-soft);
  border-radius: var(--r-md); padding: 28px 20px; cursor: pointer;
  display: flex; flex-direction: column; align-items: center; gap: 12px; width: 100%;
}
.drop--ok { border-color: var(--green); background: rgba(26,128,64,.05); }
.drop__judul { font: 600 13.5px var(--font-display); }
.drop__ket { font: 400 11.5px var(--font-body); color: var(--muted); }
.pratinjau {
  width: 150px; height: 196px; background: #fff; border: 1px solid var(--line);
  border-radius: var(--r-sm); display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 8px;
  font: 400 10.5px/1.4 var(--font-body); color: var(--muted); text-align: center; padding: 0 12px;
}
.ok { font: 600 12.5px var(--font-body); color: var(--green); }
.ganti { font: 500 12px var(--font-body); color: var(--blue); }
.spacer { flex: 1; }
</style>
