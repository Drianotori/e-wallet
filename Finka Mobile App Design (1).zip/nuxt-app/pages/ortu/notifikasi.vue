<template>
  <div class="wrap">
    <ScreenHeader title="Notifikasi" to="/ortu" />
    <div class="body">
      <div v-for="(n, i) in notifikasi" :key="i" class="card notif" :class="n.baru ? 'notif--baru' : ''">
        <span class="dot"></span>
        <div class="notif__body">
          <div class="notif__head">
            <span class="notif__judul display">{{ n.judul }}</span>
            <span class="notif__waktu">{{ n.waktu }}</span>
          </div>
          <p>{{ n.isi }}</p>
        </div>
      </div>
    </div>
    <OrtuTabBar />
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    notifikasi() { return this.$store.state.topup.notifikasi }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: var(--bg); min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 16px 18px; display: flex; flex-direction: column; gap: 10px; }
.notif { padding: 14px; display: flex; gap: 12px; }
.notif--baru { border-color: var(--blue); }
.dot { width: 8px; height: 8px; border-radius: var(--r-pill); background: var(--line); margin-top: 6px; flex: none; }
.notif--baru .dot { background: var(--blue); }
.notif__body { flex: 1; }
.notif__head { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
.notif__judul { font: 700 13.5px var(--font-display); }
.notif__waktu { font: 400 11px var(--font-body); color: var(--muted); white-space: nowrap; }
.notif__body p { margin: 3px 0 0; font: 400 12.5px/1.5 var(--font-body); color: var(--muted); text-wrap: pretty; }
</style>
