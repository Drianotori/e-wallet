<template>
  <div class="wrap">
    <div class="scroll">
      <header class="top">
        <div class="top__bar">
          <div class="logo">
            <svg width="20" height="22" viewBox="0 0 40 44" fill="var(--blue)"><rect x="13" y="0" width="27" height="14" rx="6" /><rect x="0" y="10" width="14" height="14" rx="6" /><rect x="9" y="15" width="24" height="14" rx="6" /><rect x="4" y="30" width="14" height="14" rx="6" /></svg>
            <span class="display">Finka</span>
          </div>
          <nuxt-link to="/ortu/notifikasi" class="bell">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="var(--ink)" stroke-width="1.8"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 01-3.4 0" /></svg>
            <i></i>
          </nuxt-link>
        </div>
        <div>
          <div class="halo">Selamat pagi,</div>
          <div class="nama display">Ibu Sari Wulandari</div>
        </div>
      </header>

      <div class="sec">
        <div class="sec__head">
          <span class="display">Dompet anak</span>
          <span class="sec__meta">{{ siswa.length }} anak</span>
        </div>
        <div class="kartu-list">
          <nuxt-link
            v-for="(a, i) in siswa"
            :key="a.id"
            :to="'/ortu/riwayat?anak=' + a.id"
            class="kartu"
            :class="i === 0 ? 'kartu--navy' : ''"
          >
            <div class="kartu__top">
              <div class="av">{{ a.inisial }}</div>
              <div class="kartu__id">
                <div class="kartu__nama display">{{ a.nama }}</div>
                <div class="kartu__sub">{{ a.kelas }} · NIS {{ a.nis }}</div>
              </div>
              <div class="kartu__sub">Lihat</div>
            </div>
            <div class="kartu__bot">
              <div>
                <div class="kartu__label">SALDO</div>
                <div class="kartu__saldo display num" :class="!menipis(a) ? '' : 'is-low'">{{ a.saldo | rp }}</div>
              </div>
              <span v-if="menipis(a)" class="tag-low">Saldo menipis</span>
            </div>
          </nuxt-link>
        </div>
      </div>

      <div class="aksi">
        <nuxt-link to="/ortu/isi-saldo" class="aksi__box aksi__box--primary">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"><path d="M12 5v14M5 12h14" /></svg>
          <span class="display">Isi Saldo</span>
        </nuxt-link>
        <nuxt-link to="/ortu/tagihan" class="aksi__box">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ink)" stroke-width="1.8"><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h8M8 12h8M8 16h4" /></svg>
          <span class="aksi__label"><span class="display">Tagihan SPP</span><i class="pip">{{ belumBayar }}</i></span>
        </nuxt-link>
      </div>

      <div class="sec sec--last">
        <div class="sec__head">
          <span class="display">Aktivitas terakhir</span>
          <nuxt-link to="/ortu/riwayat" class="link">Semua</nuxt-link>
        </div>
        <div class="card">
          <TrxRow v-for="t in terakhir" :key="t.id" :trx="t" :to="'/ortu/riwayat?trx=' + t.id" />
        </div>
      </div>
    </div>

    <OrtuTabBar />
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    siswa() { return this.$store.state.siswa },
    terakhir() { return this.$store.state.trx.slice(0, 3) },
    belumBayar() { return this.$store.state.tagihan.filter((b) => b.status === 'Belum Bayar').length }
  },
  methods: {
    menipis(a) { return a.saldo < this.$store.state.ambangMenipis }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; min-height: 0; }
.scroll { flex: 1; overflow-y: auto; background: var(--bg); }

.top { background: #fff; padding: 8px 20px 22px; display: flex; flex-direction: column; gap: 20px; }
.top__bar { display: flex; align-items: center; justify-content: space-between; }
.logo { display: flex; align-items: center; gap: 10px; font: 800 17px var(--font-display); color: var(--ink); }
.bell {
  position: relative; width: 38px; height: 38px; border-radius: var(--r-pill);
  background: var(--bg); display: flex; align-items: center; justify-content: center;
}
.bell:hover { background: var(--blue-soft); }
.bell i { position: absolute; top: 7px; right: 8px; width: 8px; height: 8px; border-radius: var(--r-pill); background: var(--coral); border: 2px solid #fff; }
.halo { font: 400 13px var(--font-body); color: var(--muted); }
.nama { font: 700 20px var(--font-display); margin-top: 2px; }

.sec { padding: 18px 20px 0; }
.sec--last { padding-bottom: 24px; }
.sec__head { display: flex; align-items: center; justify-content: space-between; font: 700 13px var(--font-display); margin-bottom: 12px; }
.sec__meta { font: 500 12px var(--font-body); color: var(--muted); }
.link { font: 600 12px var(--font-body); }

.kartu-list { display: flex; flex-direction: column; gap: 12px; }
.kartu {
  background: #fff; border: 1px solid var(--line); border-radius: var(--r-md);
  padding: 16px; display: flex; flex-direction: column; gap: 14px; color: var(--ink);
}
.kartu--navy { background: var(--navy); border-color: var(--navy); color: #fff; }
.kartu:hover { color: inherit; }
.kartu__top { display: flex; align-items: center; gap: 12px; }
.av {
  width: 44px; height: 44px; border-radius: var(--r-pill); flex: none;
  background: var(--blue-soft); color: var(--blue);
  display: flex; align-items: center; justify-content: center;
  font: 700 15px var(--font-display);
}
.kartu--navy .av { background: rgba(255,255,255,.14); color: #fff; }
.kartu__id { flex: 1; min-width: 0; }
.kartu__nama { font: 700 15px var(--font-display); }
.kartu__sub { font: 400 12.5px var(--font-body); color: var(--muted); margin-top: 2px; }
.kartu--navy .kartu__sub { color: rgba(255,255,255,.55); }
.kartu__bot { display: flex; align-items: flex-end; justify-content: space-between; }
.kartu__label { font: 500 11px var(--font-body); color: var(--muted); letter-spacing: .04em; }
.kartu--navy .kartu__label { color: rgba(255,255,255,.55); }
.kartu__saldo { font: 700 26px var(--font-display); letter-spacing: -.02em; margin-top: 2px; }
.kartu__saldo.is-low { color: var(--coral); }
.kartu--navy .kartu__saldo.is-low { color: #fff; }
.tag-low { background: var(--coral); color: #fff; font: 600 11px var(--font-body); padding: 5px 10px; border-radius: var(--r-pill); }

.aksi { padding: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.aksi__box {
  background: #fff; border: 1px solid var(--line); border-radius: var(--r-md);
  padding: 16px; display: flex; flex-direction: column; gap: 24px;
  color: var(--ink); font: 700 14px var(--font-display);
}
.aksi__box:hover { border-color: var(--blue); color: var(--ink); }
.aksi__box--primary { background: var(--blue); border-color: var(--blue); color: #fff; }
.aksi__box--primary:hover { background: var(--blue-dark); color: #fff; }
.aksi__label { display: flex; align-items: center; gap: 8px; }
.pip {
  background: var(--coral); color: #fff; font: 700 10px var(--font-body); font-style: normal;
  min-width: 17px; height: 17px; border-radius: var(--r-pill);
  display: flex; align-items: center; justify-content: center; padding: 0 5px;
}
</style>
