<template>
  <div class="wrap">
    <ScreenHeader title="Detail Tagihan" to="/ortu/tagihan" />
    <div class="body">
      <div class="head">
        <div class="periode">{{ bill.periode }}</div>
        <div class="nama display">{{ bill.nama }}</div>
        <div class="nominal display num">{{ bill.nominal | rp }}</div>
      </div>

      <div class="card rincian">
        <div><span>Siswa</span><b>{{ bill.anak }}</b></div>
        <div><span>Jatuh tempo</span><b class="due">{{ bill.tempo }}</b></div>
        <div><span>Status</span><b>{{ bill.status }}</b></div>
      </div>

      <div class="cara">
        <div class="cara__judul display">Cara bayar</div>
        <p>Transfer ke rekening yayasan dengan nominal berkode unik, lalu unggah bukti. Tagihan menjadi lunas setelah admin memverifikasi.</p>
      </div>

      <div class="spacer"></div>
      <button class="btn btn--primary" @click="bayar">Bayar tagihan ini</button>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    bill() { return this.$store.getters.tagihanById(this.$route.params.id) }
  },
  methods: {
    bayar() {
      this.$store.dispatch('topup/mulaiTopup', this.bill.nominal)
      this.$router.push('/ortu/isi-saldo')
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: #fff; min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 18px; }
.head { display: flex; flex-direction: column; gap: 6px; }
.periode { font: 600 12px var(--font-body); color: var(--muted); }
.nama { font: 700 19px var(--font-display); }
.nominal { font: 800 32px var(--font-display); letter-spacing: -.02em; margin-top: 6px; }

.rincian { padding: 16px; display: flex; flex-direction: column; gap: 10px; }
.rincian div { display: flex; justify-content: space-between; }
.rincian span { font: 400 12.5px var(--font-body); color: var(--muted); }
.rincian b { font: 600 12.5px var(--font-body); }
.due { color: var(--coral); }

.cara { background: var(--blue-soft); border-radius: var(--r-md); padding: 16px; display: flex; flex-direction: column; gap: 8px; }
.cara__judul { font: 700 12.5px var(--font-display); }
.cara p { margin: 0; font: 400 12.5px/1.5 var(--font-body); color: var(--muted); text-wrap: pretty; }
.spacer { flex: 1; }
</style>
