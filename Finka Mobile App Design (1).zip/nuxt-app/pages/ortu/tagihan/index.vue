<template>
  <div class="wrap">
    <ScreenHeader title="Tagihan" to="/ortu" />
    <div class="body">
      <div class="peringatan">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9"><circle cx="12" cy="12" r="9" /><path d="M12 8v5M12 16h.01" /></svg>
        <p><b>{{ belumBayar }} tagihan jatuh tempo 10 Sep.</b> Denda keterlambatan berlaku setelah tanggal tersebut.</p>
      </div>

      <nuxt-link
        v-for="b in tagihan"
        :key="b.id"
        :to="'/ortu/tagihan/' + b.id"
        class="card bill"
        :class="b.status === 'Belum Bayar' ? 'bill--due' : ''"
      >
        <div class="bill__top">
          <div>
            <div class="bill__nama display">{{ b.nama }}</div>
            <div class="bill__sub">{{ b.anak }} · {{ b.periode }}</div>
          </div>
          <span class="badge" :class="badge(b.status)">{{ b.status }}</span>
        </div>
        <div class="bill__bot">
          <span class="bill__nominal display num">{{ b.nominal | rp }}</span>
          <span class="bill__tempo" :class="b.status === 'Belum Bayar' ? 'is-due' : ''">{{ b.tempo }}</span>
        </div>
      </nuxt-link>
    </div>
    <OrtuTabBar />
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    tagihan() { return this.$store.state.tagihan },
    belumBayar() { return this.tagihan.filter((b) => b.status === 'Belum Bayar').length }
  },
  methods: {
    badge(s) {
      if (s === 'Lunas') return 'badge--ok'
      if (s === 'Menunggu Verifikasi') return 'badge--warn'
      return 'badge--bad'
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: var(--bg); min-height: 0; }
.body { flex: 1; overflow-y: auto; padding: 18px; display: flex; flex-direction: column; gap: 14px; }

.peringatan { background: var(--coral); border-radius: var(--r-md); padding: 16px; display: flex; align-items: center; gap: 13px; }
.peringatan svg { flex: none; }
.peringatan p { margin: 0; font: 400 12.5px/1.45 var(--font-body); color: #fff; text-wrap: pretty; }

.bill { padding: 16px; display: flex; flex-direction: column; gap: 12px; color: inherit; }
.bill:hover { color: inherit; border-color: var(--blue); }
.bill--due { border-color: var(--coral); }
.bill__top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
.bill__nama { font: 700 14.5px var(--font-display); }
.bill__sub { font: 400 12px var(--font-body); color: var(--muted); margin-top: 3px; }
.bill__bot { display: flex; align-items: flex-end; justify-content: space-between; }
.bill__nominal { font: 700 19px var(--font-display); }
.bill__tempo { font: 400 11.5px var(--font-body); color: var(--muted); }
.bill__tempo.is-due { color: var(--coral); }
</style>
