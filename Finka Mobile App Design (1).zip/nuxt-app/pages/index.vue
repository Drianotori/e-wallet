<template>
  <div class="home">
    <h1 class="brand display">Finka</h1>
    <p class="lead">Tiga aplikasi mobile dan satu dashboard yayasan. Pilih role untuk membuka alurnya.</p>
    <div class="grid">
      <nuxt-link v-for="r in roles" :key="r.to" :to="r.to" class="card role">
        <div class="dot" :style="'background:' + r.warna"></div>
        <div class="role__nama display">{{ r.nama }}</div>
        <div class="role__ket">{{ r.ket }}</div>
        <div class="role__route num">{{ r.to }}</div>
      </nuxt-link>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      roles: [
        { nama: 'Orang Tua / Wali', ket: 'Dompet anak, isi saldo dengan kode unik, tagihan SPP, limit dan blokir kartu.', to: '/ortu', warna: 'var(--blue)' },
        { nama: 'Siswa', ket: 'Saldo, barcode pembayaran, riwayat jajan, dan struk digital.', to: '/siswa', warna: 'var(--sand)' },
        { nama: 'PIC — Kasir', ket: 'Katalog kantin dan koperasi, scan barcode, PIN siswa, ambil tunai.', to: '/pic', warna: 'var(--coral)' },
        { nama: 'Admin Yayasan', ket: 'Verifikasi top-up, penerbitan invoice, laporan, dan audit log.', to: '/admin', warna: 'var(--navy)' }
      ]
    }
  }
}
</script>

<style scoped>
.home { max-width: 880px; width: 100%; padding: 40px 0; }
.brand { font: 800 30px var(--font-display); letter-spacing: -.02em; margin: 0; }
.lead { font: 400 14px var(--font-body); color: var(--muted); max-width: 520px; margin: 10px 0 30px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; }
.role { padding: 20px; display: flex; flex-direction: column; gap: 8px; color: inherit; }
.role:hover { border-color: var(--blue); color: inherit; }
.dot { width: 9px; height: 9px; border-radius: var(--r-pill); }
.role__nama { font: 700 16px var(--font-display); margin-top: 4px; }
.role__ket { font: 400 12.5px/1.55 var(--font-body); color: var(--muted); text-wrap: pretty; }
.role__route { font: 500 11.5px var(--font-body); color: var(--blue); margin-top: 6px; }
</style>
