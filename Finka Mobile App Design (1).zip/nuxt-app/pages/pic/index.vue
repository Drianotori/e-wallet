<template>
  <div class="wrap">
    <header class="head">
      <div>
        <div class="outlet display">Kantin Utama</div>
        <div class="sesi">Sesi #KU-0902 · Bu Ratna · buka 07.00</div>
      </div>
      <div class="kanan">
        <span class="badge badge--ok">Online</span>
        <span class="kas num">Kas tunai {{ kasSesi | rp }}</span>
      </div>
    </header>

    <div class="tabs">
      <button
        v-for="(t, i) in ['Kantin', 'Koperasi']"
        :key="t"
        class="chip chip--pill"
        :class="outlet === i ? 'chip--on' : ''"
        @click="setOutlet(i)"
      >{{ t }}</button>
    </div>

    <div class="grid">
      <button v-for="p in produk" :key="p.id" class="prod" :class="cart[p.id] ? 'prod--on' : ''" @click="tambah(p.id)">
        <div class="prod__top">
          <span class="tile">{{ p.tile }}</span>
          <span v-if="cart[p.id]" class="qty">{{ cart[p.id] }}</span>
        </div>
        <div class="prod__body">
          <div class="prod__nama">{{ p.nama }}</div>
          <div class="prod__ket">{{ p.ket }}</div>
        </div>
        <div class="prod__harga display num">{{ p.harga | rp }}</div>
      </button>
    </div>

    <footer class="foot">
      <div class="foot__row">
        <span class="foot__count">{{ jumlah }} item</span>
        <button class="kosong" :class="total ? '' : 'is-off'" @click="kosongkan">Kosongkan</button>
      </div>
      <div class="foot__row foot__row--total">
        <span>Total</span>
        <span class="display num">{{ total | rp }}</span>
      </div>
      <div class="foot__aksi">
        <button class="btn" :class="total ? 'btn--primary' : 'btn--off'" :disabled="!total" @click="scan">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2M3 12h18" /></svg>
          Scan siswa
        </button>
        <nuxt-link to="/pic/tunai" class="tunai display">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><rect x="2" y="6" width="20" height="12" rx="2" /><circle cx="12" cy="12" r="2.6" /><path d="M6 12h.01M18 12h.01" /></svg>
          Tunai
        </nuxt-link>
      </div>
    </footer>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    outlet() { return this.$store.state.pos.outlet },
    cart() { return this.$store.state.pos.cart },
    kasSesi() { return this.$store.state.pos.kasSesi },
    produk() { return this.$store.getters.produkOutlet(this.outlet) },
    total() { return this.$store.getters['pos/totalBelanja'] },
    jumlah() { return this.$store.getters['pos/jumlahItem'] }
  },
  methods: {
    setOutlet(i) { this.$store.commit('pos/setOutlet', i) },
    tambah(id) { this.$store.commit('pos/tambah', id) },
    kosongkan() { this.$store.commit('pos/kosongkan') },
    scan() {
      if (!this.total) return
      this.$store.commit('pos/setMode', 'belanja')
      this.$router.push('/pic/scan')
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: #fff; min-height: 0; }
.head { padding: 8px 18px 14px; border-bottom: 1px solid var(--line); display: flex; align-items: center; justify-content: space-between; gap: 12px; flex: none; }
.outlet { font: 700 15px var(--font-display); }
.sesi { font: 400 11.5px var(--font-body); color: var(--muted); margin-top: 2px; }
.kanan { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; }
.kas { font: 400 10.5px var(--font-body); color: var(--muted); }

.tabs { padding: 14px 18px 10px; display: flex; gap: 8px; flex: none; }
.grid { flex: 1; overflow-y: auto; padding: 6px 18px 14px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; align-content: start; }
.prod {
  border: 1px solid var(--line); background: #fff; border-radius: var(--r-md);
  padding: 13px; display: flex; flex-direction: column; gap: 10px;
  cursor: pointer; min-height: 104px; text-align: left;
}
.prod--on { border-color: var(--blue); background: var(--blue-soft); }
.prod__top { display: flex; align-items: flex-start; justify-content: space-between; }
.tile {
  width: 30px; height: 30px; border-radius: var(--r-sm);
  background: var(--bg); color: var(--muted);
  display: flex; align-items: center; justify-content: center; font: 700 12px var(--font-display);
}
.prod--on .tile { background: var(--blue); color: #fff; }
.qty {
  min-width: 22px; height: 22px; border-radius: var(--r-pill);
  background: var(--blue); color: #fff; font: 700 11.5px var(--font-body);
  display: flex; align-items: center; justify-content: center; padding: 0 6px;
}
.prod__body { flex: 1; }
.prod__nama { font: 600 13px/1.35 var(--font-body); text-wrap: pretty; }
.prod__ket { font: 400 11px var(--font-body); color: var(--muted); margin-top: 2px; }
.prod__harga { font: 700 13.5px var(--font-display); }

.foot { border-top: 1px solid var(--line); padding: 14px 18px 22px; display: flex; flex-direction: column; gap: 12px; flex: none; }
.foot__row { display: flex; align-items: center; justify-content: space-between; font: 400 12.5px var(--font-body); color: var(--muted); }
.foot__row--total { align-items: flex-end; }
.foot__row--total span:last-child { font: 800 26px var(--font-display); color: var(--ink); letter-spacing: -.02em; }
.kosong { border: none; background: none; font: 600 12px var(--font-body); color: var(--coral); cursor: pointer; padding: 0; }
.kosong.is-off { color: var(--disabled); }
.foot__aksi { display: flex; gap: 10px; }
.foot__aksi .btn { flex: 1; }
.tunai {
  flex: none; border: 1.5px solid var(--blue); color: var(--blue);
  font: 700 15px var(--font-display); padding: 16px 18px; border-radius: var(--r-sm);
  display: flex; align-items: center; gap: 9px;
}
.tunai:hover { color: var(--blue); background: var(--blue-soft); }
</style>
