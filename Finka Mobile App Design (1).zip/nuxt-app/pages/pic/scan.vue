<template>
  <div class="wrap">
    <ScreenHeader title="Scan Barcode" :to="kembali" dark />
    <div class="stage">
      <div class="viewfinder">
        <i class="c c--tl"></i><i class="c c--tr"></i><i class="c c--bl"></i><i class="c c--br"></i>
        <span class="ph">pratinjau kamera<br />(placeholder)</span>
        <i class="laser"></i>
      </div>
      <p class="hint">Arahkan ke QR di HP siswa atau kartu fisik</p>

      <div class="simulasi">
        <div class="simulasi__label">SIMULASI SCAN</div>
        <button v-for="s in siswa" :key="s.id" class="kandidat" @click="pilih(s.id)">
          <span class="av">{{ s.inisial }}</span>
          <span class="kandidat__id">
            <b>{{ s.nama }}</b>
            <i>{{ s.kelas }} · saldo {{ s.saldo | rp }}{{ s.saldo >= total ? '' : ' — kurang' }}</i>
          </span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="2" stroke-linecap="round"><path d="M9 6l6 6-6 6" /></svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    siswa() { return this.$store.state.siswa },
    total() { return this.$store.getters['pos/total'] },
    kembali() { return this.$store.state.pos.mode === 'tunai' ? '/pic/tunai' : '/pic' }
  },
  methods: {
    pilih(id) {
      this.$store.commit('pos/setScan', id)
      this.$router.push('/pic/konfirmasi')
    }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; background: var(--navy); min-height: 0; }
.stage { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 22px; padding: 0 22px 26px; }

.viewfinder {
  width: 250px; height: 250px; border-radius: var(--r-lg);
  background: rgba(255,255,255,.05); position: relative;
  display: flex; align-items: center; justify-content: center;
}
.c { position: absolute; width: 44px; height: 44px; border: 0 solid var(--sand); }
.c--tl { top: 0; left: 0; border-top-width: 3px; border-left-width: 3px; border-radius: 16px 0 0 0; }
.c--tr { top: 0; right: 0; border-top-width: 3px; border-right-width: 3px; border-radius: 0 16px 0 0; }
.c--bl { bottom: 0; left: 0; border-bottom-width: 3px; border-left-width: 3px; border-radius: 0 0 0 16px; }
.c--br { bottom: 0; right: 0; border-bottom-width: 3px; border-right-width: 3px; border-radius: 0 0 16px 0; }
.ph { font: 400 11.5px/1.5 var(--font-body); color: rgba(255,255,255,.35); text-align: center; padding: 0 30px; }
.laser { position: absolute; left: 14px; right: 14px; height: 2px; background: var(--sand); animation: fkPulse 1.4s ease-in-out infinite; }

.hint { margin: 0; font: 400 12.5px var(--font-body); color: rgba(255,255,255,.6); text-align: center; }
.simulasi { display: flex; flex-direction: column; gap: 9px; width: 100%; }
.simulasi__label { font: 500 11px var(--font-body); color: rgba(255,255,255,.35); letter-spacing: .08em; text-align: center; }
.kandidat {
  border: none; background: rgba(255,255,255,.08); border-radius: var(--r-sm);
  padding: 13px 15px; display: flex; align-items: center; gap: 12px; cursor: pointer; width: 100%;
}
.kandidat:hover { background: rgba(255,255,255,.14); }
.av {
  width: 32px; height: 32px; border-radius: var(--r-pill);
  background: rgba(255,255,255,.14); color: #fff;
  display: flex; align-items: center; justify-content: center; font: 700 12px var(--font-display);
}
.kandidat__id { flex: 1; text-align: left; }
.kandidat__id b { display: block; font: 600 13px var(--font-body); color: #fff; }
.kandidat__id i { display: block; font: 400 11px var(--font-body); color: rgba(255,255,255,.5); font-style: normal; }
</style>
