<template>
  <div class="card tabel">
    <div class="tabel__head">
      <div>
        <div class="h display">Audit log</div>
        <div class="sub">Semua aksi Admin dan PIC. Tidak bisa dihapus atau diubah.</div>
      </div>
      <button class="btn-sm">Ekspor CSV</button>
    </div>
    <div class="baris baris--head">
      <div>WAKTU</div><div>AKTOR</div><div>AKSI</div><div>PERUBAHAN</div><div>IP</div>
    </div>
    <div v-for="(a, i) in rows" :key="i" class="baris">
      <div class="muted num">{{ a.waktu }}</div>
      <div><b>{{ a.aktor }}</b><i>{{ a.peran }}</i></div>
      <div><span class="aksi" :class="kelasAksi(a.aksi)">{{ a.aksi }}</span></div>
      <div class="ubah num">{{ a.perubahan }}</div>
      <div class="muted num">{{ a.ip }}</div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'admin',
  data() {
    return {
      merah: ['TOLAK_TOPUP', 'PIN_GAGAL', 'BLOKIR_KARTU'],
      biru: ['SETUJUI_TOPUP', 'UBAH_PRODUK', 'TERBIT_TAGIHAN'],
      rows: [
        { waktu: '09.52.14', aktor: 'Hendra Wijaya', peran: 'Admin', aksi: 'SETUJUI_TOPUP', perubahan: 'TU-2609-0413 · saldo +Rp 1.000.110', ip: '10.2.4.17' },
        { waktu: '09.48.30', aktor: 'Hendra Wijaya', peran: 'Admin', aksi: 'TERBIT_TAGIHAN', perubahan: 'INV/2026/09/0128 · 30 invoice · Rp 13.500.000', ip: '10.2.4.17' },
        { waktu: '09.44.02', aktor: 'Bu Ratna', peran: 'PIC Kantin Utama', aksi: 'TRANSAKSI_POS', perubahan: 'TRX-0902-0187 · Rp 19.000', ip: '10.2.9.44' },
        { waktu: '09.38.51', aktor: 'Sari Wulandari', peran: 'Orang tua', aksi: 'BLOKIR_KARTU', perubahan: 'Kayla Pratama · kartu nonaktif', ip: '182.1.x.x' },
        { waktu: '09.31.20', aktor: 'Bu Ratna', peran: 'PIC Kantin Utama', aksi: 'AMBIL_TUNAI', perubahan: 'TRX-0902-0186 · Rp 50.000', ip: '10.2.9.44' },
        { waktu: '09.12.33', aktor: 'Bu Ratna', peran: 'PIC Kantin Utama', aksi: 'PIN_GAGAL', perubahan: 'Rafi Ramadhan · percobaan 2 dari 3', ip: '10.2.9.44' },
        { waktu: '08.55.09', aktor: 'Hendra Wijaya', peran: 'Admin', aksi: 'UBAH_PRODUK', perubahan: 'Susu kotak · stok 12 → 0', ip: '10.2.4.17' },
        { waktu: '08.20.47', aktor: 'Hendra Wijaya', peran: 'Admin', aksi: 'TOLAK_TOPUP', perubahan: 'TU-2609-0410 · alasan: bukti tidak terbaca', ip: '10.2.4.17' },
        { waktu: '07.02.11', aktor: 'Pak Yusuf', peran: 'PIC Koperasi', aksi: 'BUKA_SESI', perubahan: 'Koperasi Sekolah · kas awal Rp 200.000', ip: '10.2.9.51' }
      ]
    }
  },
  methods: {
    kelasAksi(a) {
      if (this.merah.indexOf(a) >= 0) return 'aksi--merah'
      if (this.biru.indexOf(a) >= 0) return 'aksi--biru'
      return ''
    }
  }
}
</script>

<style scoped>
.tabel { overflow: hidden; }
.tabel__head { padding: 16px 20px; border-bottom: 1px solid var(--line); display: flex; align-items: center; justify-content: space-between; }
.h { font: 700 14px var(--font-display); }
.sub { font: 400 12px var(--font-body); color: var(--muted); margin-top: 3px; }
.btn-sm { border: 1px solid var(--line); background: #fff; color: var(--ink); font: 600 12.5px var(--font-body); padding: 9px 15px; border-radius: var(--r-sm); cursor: pointer; }

.baris { display: grid; grid-template-columns: .9fr 1.1fr 1.5fr 1.7fr .8fr; padding: 13px 20px; border-top: 1px solid var(--bg); align-items: center; }
.baris--head { padding: 11px 20px; background: var(--bg); border-top: none; font: 600 11.5px var(--font-body); color: var(--muted); letter-spacing: .03em; }
.muted { font: 400 12.5px var(--font-body); color: var(--muted); }
.baris b { display: block; font: 600 12.5px var(--font-body); }
.baris i { display: block; font: 400 11px var(--font-body); color: var(--muted); font-style: normal; margin-top: 1px; }
.aksi { background: var(--bg); color: var(--muted); font: 600 11px var(--font-body); padding: 5px 10px; border-radius: 6px; }
.aksi--merah { background: rgba(223,74,55,.1); color: var(--coral); }
.aksi--biru { background: var(--blue-soft); color: var(--blue); }
.ubah { font: 400 12.5px var(--font-body); }
</style>
