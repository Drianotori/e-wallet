<template>
  <div class="page">
    <div class="card rekon">
      <div class="rekon__head">
        <div>
          <div class="h display">Rekonsiliasi harian — 1 September 2026</div>
          <div class="sub">Uang masuk, uang keluar, dan perubahan saldo agregat harus nol selisih</div>
        </div>
        <div class="ekspor">
          <button class="btn-sm">Ekspor PDF</button>
          <button class="btn-sm">Ekspor Excel</button>
        </div>
      </div>
      <div class="grid">
        <div v-for="r in rekon" :key="r.label" class="box" :class="r.bad ? 'box--bad' : ''">
          <div class="box__label">{{ r.label }}</div>
          <div class="box__nilai display num" :style="'color:' + (r.bad ? 'var(--coral)' : 'var(--ink)')">{{ r.nilai }}</div>
          <div class="box__ket">{{ r.ket }}</div>
        </div>
      </div>
    </div>

    <div class="card tabel">
      <div class="tabel__head h display">Ringkasan per outlet — 1–2 September</div>
      <div class="baris baris--head">
        <div>OUTLET</div><div>TRANSAKSI</div><div>OMZET</div><div>RATA-RATA</div><div>VOID / REFUND</div>
      </div>
      <div v-for="l in rows" :key="l.nama" class="baris">
        <div><b>{{ l.nama }}</b><i>PIC {{ l.pic }}</i></div>
        <div class="muted num">{{ l.trx }}</div>
        <div class="tebal num">{{ l.omzet | rp }}</div>
        <div class="muted num">{{ l.rata | rp }}</div>
        <div class="tebal num" :style="'color:' + (l.void > 50000 ? 'var(--coral)' : l.void ? 'var(--sand-ink)' : 'var(--muted)')">{{ l.void | rp }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'admin',
  computed: {
    rekon() {
      return [
        { label: 'Top-up disetujui', nilai: this.$rp(6120000), ket: '41 permintaan' },
        { label: 'Transaksi POS', nilai: this.$rp(3241000), ket: '386 struk' },
        { label: 'Perubahan saldo agregat', nilai: this.$rp(2855000), ket: 'seharusnya Rp 2.879.000' },
        { label: 'Selisih', nilai: '− ' + this.$num(24000), ket: 'perlu ditelusuri', bad: true }
      ]
    },
    rows() {
      return [
        { nama: 'Kantin Utama', pic: 'Bu Ratna', trx: 214, omzet: 1840000, rata: 8598, void: 30000 },
        { nama: 'Kantin Blok B', pic: 'Bu Lilis', trx: 97, omzet: 760000, rata: 7835, void: 0 },
        { nama: 'Koperasi Sekolah', pic: 'Pak Yusuf', trx: 36, omzet: 385000, rata: 10694, void: 85000 },
        { nama: 'Ambil tunai (kasir)', pic: 'Bu Ratna', trx: 12, omzet: 640000, rata: 53333, void: 0 }
      ]
    }
  }
}
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 18px; }
.rekon { padding: 22px; display: flex; flex-direction: column; gap: 20px; }
.rekon__head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
.h { font: 700 15px var(--font-display); }
.sub { font: 400 12.5px var(--font-body); color: var(--muted); margin-top: 3px; }
.ekspor { display: flex; gap: 9px; }
.btn-sm { border: 1px solid var(--line); background: #fff; color: var(--ink); font: 600 12.5px var(--font-body); padding: 9px 15px; border-radius: var(--r-sm); cursor: pointer; }

.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.box { border: 1px solid var(--line); border-radius: var(--r-md); padding: 16px; display: flex; flex-direction: column; gap: 7px; }
.box--bad { border-color: var(--coral); background: rgba(223,74,55,.04); }
.box__label { font: 500 11.5px var(--font-body); color: var(--muted); }
.box__nilai { font: 800 22px var(--font-display); letter-spacing: -.02em; }
.box__ket { font: 400 11px var(--font-body); color: var(--muted); }

.tabel { overflow: hidden; }
.tabel__head { padding: 16px 20px; border-bottom: 1px solid var(--line); font-size: 14px; }
.baris { display: grid; grid-template-columns: 1.6fr 1fr 1fr 1fr 1fr; padding: 14px 20px; border-top: 1px solid var(--bg); align-items: center; }
.baris--head { padding: 11px 20px; background: var(--bg); border-top: none; font: 600 11.5px var(--font-body); color: var(--muted); letter-spacing: .03em; }
.baris b { display: block; font: 600 13px var(--font-body); }
.baris i { display: block; font: 400 11px var(--font-body); color: var(--muted); font-style: normal; margin-top: 1px; }
.muted { font: 400 13px var(--font-body); color: var(--muted); }
.tebal { font: 600 13px var(--font-body); }
</style>
