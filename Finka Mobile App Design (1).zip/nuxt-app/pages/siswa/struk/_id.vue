<template>
  <div class="wrap">
    <ScreenHeader title="Struk Digital" to="/siswa/riwayat" dark />
    <div v-if="trx" class="sheet">
      <div class="head">
        <div class="cek">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
        </div>
        <div class="judul display">{{ trx.judul }}</div>
        <div class="nominal display num">{{ Math.abs(trx.nominal) | rp }}</div>
        <div class="waktu">{{ trx.hari }} · {{ jam }} WIB</div>
      </div>

      <div class="putus"></div>
      <div class="items">
        <div v-for="(i, k) in trx.items" :key="k" class="item">
          <span>{{ i.nama }}</span>
          <b class="num">{{ i.harga | rp }}</b>
        </div>
      </div>

      <div class="putus"></div>
      <div class="meta">
        <div><span>Outlet</span><b>{{ trx.outlet }}</b></div>
        <div><span>Kasir</span><b>{{ trx.kasir }}</b></div>
        <div><span>Saldo sebelum</span><b class="num">{{ sebelum | rp }}</b></div>
        <div><span>Saldo sesudah</span><b class="num">{{ trx.sisa | rp }}</b></div>
        <div><span>ID transaksi</span><b class="num">{{ idTrx }}</b></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  computed: {
    trx() { return this.$store.getters.trxById(this.$route.params.id) },
    jam() { return this.trx ? this.trx.meta.split(' · ')[0] : '' },
    sebelum() { return this.trx ? this.trx.sisa + Math.abs(this.trx.nominal) : 0 },
    idTrx() { return this.trx ? 'TRX-0902-01' + this.trx.id.slice(1) + '4' : '' }
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; overflow-y: auto; min-height: 0; }
.sheet { flex: 1; background: #fff; border-radius: 24px 24px 0 0; padding: 26px 22px; display: flex; flex-direction: column; gap: 20px; }
.head { display: flex; flex-direction: column; align-items: center; gap: 10px; }
.cek { width: 48px; height: 48px; border-radius: var(--r-pill); background: rgba(26,128,64,.12); display: flex; align-items: center; justify-content: center; }
.judul { font: 700 16px var(--font-display); }
.nominal { font: 800 30px var(--font-display); letter-spacing: -.02em; }
.waktu { font: 400 12px var(--font-body); color: var(--muted); }
.putus { border-top: 1px dashed var(--line); }
.items { display: flex; flex-direction: column; gap: 10px; }
.item { display: flex; justify-content: space-between; gap: 12px; font: 400 13px var(--font-body); }
.item b { font-weight: 600; white-space: nowrap; }
.meta { display: flex; flex-direction: column; gap: 9px; }
.meta div { display: flex; justify-content: space-between; }
.meta span { font: 400 12.5px var(--font-body); color: var(--muted); }
.meta b { font: 600 12.5px var(--font-body); }
</style>
