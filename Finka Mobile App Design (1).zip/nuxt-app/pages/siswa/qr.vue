<template>
  <div class="wrap">
    <ScreenHeader title="Barcode Saya" to="/siswa" dark />
    <div class="stage">
      <div class="kartu">
        <div class="kartu__who">
          <div class="av">{{ siswa.inisial }}</div>
          <div>
            <div class="nama display">{{ siswa.nama }}</div>
            <div class="sub">{{ siswa.kelas }} · Saldo {{ siswa.saldo | rp }}</div>
          </div>
        </div>
        <div class="qr"><QrCode :size="224" :cell="10" :seed="detik" /></div>
        <div class="garis"></div>
        <div class="timer">
          <i></i>
          <span class="num">Kode berganti dalam {{ detik }} detik</span>
        </div>
      </div>
      <div class="pinnote">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--sand)" stroke-width="2"><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 118 0v3" /></svg>
        <span>Kasir tetap minta PIN 6 digit kamu</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'phone',
  data() {
    return { detik: 47, timer: null }
  },
  computed: {
    siswa() { return this.$store.state.siswa[0] }
  },
  mounted() {
    this.timer = setInterval(() => { this.detik = this.detik <= 1 ? 60 : this.detik - 1 }, 1000)
  },
  beforeDestroy() {
    if (this.timer) clearInterval(this.timer)
  }
}
</script>

<style scoped>
.wrap { flex: 1; display: flex; flex-direction: column; min-height: 0; }
.stage { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 22px; padding: 0 22px 30px; }
.kartu { background: #fff; border-radius: var(--r-lg); padding: 22px; display: flex; flex-direction: column; align-items: center; gap: 16px; width: 294px; }
.kartu__who { display: flex; align-items: center; gap: 10px; align-self: stretch; }
.av {
  width: 38px; height: 38px; border-radius: var(--r-pill);
  background: var(--blue-soft); color: var(--blue);
  display: flex; align-items: center; justify-content: center; font: 700 13px var(--font-display);
}
.nama { font: 700 14px var(--font-display); }
.sub { font: 400 11.5px var(--font-body); color: var(--muted); }
.qr { width: 230px; height: 230px; display: flex; align-items: center; justify-content: center; }
.garis { align-self: stretch; height: 1px; background: var(--line); }
.timer { display: flex; align-items: center; gap: 9px; font: 500 12px var(--font-body); color: var(--muted); }
.timer i { width: 7px; height: 7px; border-radius: var(--r-pill); background: var(--green); animation: fkPulse 1.6s ease-in-out infinite; }
.pinnote {
  display: flex; align-items: center; gap: 9px;
  background: rgba(255,255,255,.08); border-radius: var(--r-pill); padding: 9px 16px;
  font: 400 12px var(--font-body); color: rgba(255,255,255,.7);
}
</style>
