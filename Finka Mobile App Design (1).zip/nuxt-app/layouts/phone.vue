<template>
  <div class="stage">
    <PhoneShell :dark="dark">
      <Nuxt />
    </PhoneShell>
  </div>
</template>

<script>
export default {
  computed: {
    dark() {
      const p = this.$route.path
      return p.indexOf('/siswa') === 0
    }
  }
}
</script>

<style scoped>
.stage {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 32px 20px;
}
</style>
