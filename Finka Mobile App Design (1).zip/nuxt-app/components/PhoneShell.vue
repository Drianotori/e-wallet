<template>
  <div class="phone" :class="dark ? 'phone--dark' : ''">
    <div class="status">
      <span class="num">09.41</span>
      <span class="status__icons">
        <i class="sig"></i>
        <i class="bat"><b></b></i>
      </span>
    </div>
    <slot />
  </div>
</template>

<script>
export default {
  name: 'PhoneShell',
  props: {
    dark: { type: Boolean, default: false }
  }
}
</script>

<style scoped>
.phone {
  width: 390px;
  height: 844px;
  background: var(--bg);
  border: 1px solid var(--line);
  border-radius: 28px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  position: relative;
}
.phone--dark { background: var(--navy); }

.status {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 22px 6px;
  font: 600 13px var(--font-body);
  color: var(--ink);
  background: #fff;
  flex: none;
}
.phone--dark .status { color: #fff; background: transparent; }

.status__icons { display: flex; gap: 5px; align-items: center; }
.sig { width: 16px; height: 9px; border: 1.5px solid currentColor; border-radius: 2px; display: block; }
.bat { width: 22px; height: 9px; border: 1.5px solid currentColor; border-radius: 3px; display: block; position: relative; }
.bat b { position: absolute; inset: 1.5px; right: 6px; background: currentColor; border-radius: 1px; }
</style>
