export default {
  head: {
    title: 'Finka',
    htmlAttrs: { lang: 'id' },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' }
    ],
    link: [
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: true },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap'
      }
    ]
  },

  css: ['~/assets/css/main.css'],
  plugins: ['~/plugins/format.js'],
  components: true,
  buildModules: [],
  modules: [],
  build: {}
}
